# Caption muted playback platform probe

Dedicated diagnostic app, separate package `com.hatsunama.captionaction.captureprobe`.
No production Caption Action source is changed or included. This tests Android's
playback-capture component with owned synthetic audio, not production Live/ASR,
models, translation, or cross-app acceptance.

## Safety and authorization

Do not install or run until source/artifact review, separate local signing approval,
and exclusive ownership of the selected test device are established. Never change
system volume upward. An isolated emulator is preferred while physical phone
ownership cannot be guaranteed. No physical-device result is claimed.

Required permissions are exactly RECORD_AUDIO, FOREGROUND_SERVICE, and
FOREGROUND_SERVICE_MEDIA_PROJECTION. Android requires RECORD_AUDIO for playback
capture even though this app has no microphone input. The Activity requests normal
runtime consent, then a new system MediaProjection grant. No shell permission
grants, consent reuse, hidden APIs, screen images, network, models or saved audio.

Before running: media index must already be zero, normal audio mode, non-fixed
volume, built-in outputs only, stable built-in speaker route, no competing playback
or capture, and no other actor changing route/volume. The app rejects unsafe
conditions. A 20 ms guard and route callbacks are abort defenses; they cannot
prove no transient audibility if another actor changes settings between checks.
If exclusive/stable conditions cannot be verified, do not run.

Arrange an independent, bounded ADB-side watchdog on the verified serial before
Begin: force-stop only this probe after 35 seconds unless complete teardown has
already been verified. Keep control of the test until stopped-state readback.
The app also has an independent 30-second deadline that terminates only its own
process if native initialization or cleanup hangs. Native teardown stays off Main;
safety guards remain armed until release and projection-stop are verified.

## Experiment

Three six-second phases use fresh AudioRecord/AudioTrack objects:
1. Truly silent source with capture allowed.
2. Owned 733 Hz sine tone, PCM16 mono 16 kHz, amplitude 6000, capture allowed.
3. Identical tone with ALLOW_CAPTURE_BY_NONE.

AudioRecord matches only this app's UID and MEDIA usage. Source gain is 1; device
media remains 0. Reads are nonblocking, 640 samples, and Java sample buffers are
wiped after aggregation and in cleanup. Startup 1.5 seconds is excluded per phase.
Only counts, RMS, peak, 733 Hz energy fraction and SHA-256 are reported in memory
and the `CaptionCaptureProbe` log tag. No raw PCM, text, screen images or files
are saved by the probe.

A positive phase needs >=32k capture samples, >=64k source playback frames,
RMS>=100 and tone energy fraction>=0.70. Silent and denied controls need RMS<2
and the same count/progress minima. Every negative must pass. Overall success is
published only after verified native/projection teardown; cancellation prevents
late PASS publication. Any uncertain native release permanently poisons that run;
no subsequent phase allocation or successful teardown can clear the failure.

A pass establishes platform own-UID muted capture on that tested device only.
Failure is diagnostic: do not raise volume, weaken source policy, bypass capture
restrictions or assume models/ASR are at fault. RECORD_AUDIO denial means capture
was not tested. Production Live/model inference requires a separate authorized
known-speech test.

## Build and tests

Android SDK36, Gradle8.13, JDK17, Kotlin1.9.24, AGP8.10.1. The build is unsigned;
never generate or copy signing keys into this project. Signing/device tasks are
blocked. The metadata-only `writeDebugSigningConfigVersions` task is allowed
while both build-type signing configurations must remain null.

Run `gradle :app:testDebugUnitTest :app:assembleDebug :app:lintDebug` in an approved
build environment. Pure JVM tests cover metrics, tone discrimination, output
preconditions, release exceptions/stalls, projection failure/stall, cancellation,
multi-phase release failure, and teardown/disarm/publication ordering. The Python structural contract check
is an additional review gate, not runtime or device proof.
